This package simply finds the root of a project based on a filename. 

**Usage**

```python
from groo import get_root
print(get_root(".my_hidden_root_file"))
```

Where `.my_hidden_root_file` sits in the root directory.
